﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ProjetFinalGestionDesNotes
{
    class Etudiant
    {

        private int numEtudiant;
        private string strNom;
        private string strPrenom;
        private string strAdresse;
        private int moyenne;

        public Etudiant(int numEtudiant, string nom, string prenom, string address)
        {

            this.numEtudiant = numEtudiant;
            this.strNom = nom;
            this.strPrenom = prenom;
            this.strAdresse = address;
            
        }

        public int getNumEtudiant()
        {

            return this.numEtudiant;

        }

        public string  getNom()
        {

            return this.strNom;

        }

        public string getPrenom()
        {

            return this.strPrenom;

        }

        public string getAdresse()
        {

            return this.strAdresse;

        }


        public int getMoyenne()
        {

            return this.moyenne;

        }



        public void setNumEtudiant(int numEtudiant)
        {

           this.numEtudiant= numEtudiant;

        }

        public void setNom(string nom)
        {

            this.strNom = nom;

        }

        public void setPrenom(string prenom)
        {

            this.strPrenom = prenom;

        }

        public void setAdresse(string adresse)
        {

            this.strAdresse = adresse;

        }

        public void setMoyenne(int moyenne)
        {

            this.moyenne = moyenne;

        }



    }


    class Cours
    {

        private int numCours;
        private string codeDuCours;
        private string titreDuCours;
        int coefficient;


       public Cours(int numCours, string codeDuCours, string titreDuCours, int coefficient)
        {

            this.numCours = numCours;
            this.codeDuCours = codeDuCours;
            this.titreDuCours = titreDuCours;
            this.coefficient = coefficient;

        }


        public int getNumCours()
        {

            return this.numCours;

        }

        public string getCodeDuCours()
        {

            return this.codeDuCours;

        }

        public string getTitreDuCours()
        {

            return this.titreDuCours;

        }

        public int getCoefficient()
        {

            return this.coefficient;

        }


        public void setNumCours(int numCours)
        {

            this.numCours = numCours;

        }

        public void setCodeDuCours(string codeDuCours)
        {

            this.codeDuCours = codeDuCours;

        }

        public void setTitreDuCours(string titreDuCours)
        {

            this.titreDuCours = titreDuCours;

        }


        public void setCoefficient(int coefficient)
        {

            this.coefficient  = coefficient;

        }

    }


    class Note{

        
        private int numEtudiant;
        private int numCours;
        private int note;


        public Note(int numEtudiant, int numCours, int note)
        {

            this.numEtudiant = numEtudiant;
            this.numCours = numCours;
            this.note = note;


        }

        public int getNumEtudiant()
        {

            return this.numEtudiant;

        }

        public int getNumCours()
        {

            return this.numCours;

        }

        public int getNote()
        {

            return this.note;

        }
 

        public void setNumEtudiant(int numEtudiant)
        {

             this.numEtudiant= numEtudiant;

        }

        public void setNumCours(int numCours)
        {

            this.numEtudiant = numCours;

        }

        public void setNote(int note)
        {

            this.note = note;

        }


    }



}
