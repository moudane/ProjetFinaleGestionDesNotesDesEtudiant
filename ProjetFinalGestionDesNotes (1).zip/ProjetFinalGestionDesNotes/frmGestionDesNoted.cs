﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

using System.IO;

namespace ProjetFinalGestionDesNotes
{
   

    public partial class frmGestionDesNoted : Form
    {
        private List<Etudiant> listEtudiant = new List<Etudiant>();
        private List<Cours> listCours = new List<Cours>();
        private List<Note> listNote = new List<Note>();

        public frmGestionDesNoted()
        {
            InitializeComponent();
        }

        private void frmGestionDesNoted_Load(object sender, EventArgs e)
        {
                   


        }

        private void label12_Click(object sender, EventArgs e)
        {

        }

        private void cmdOKEtudiant_Click(object sender, EventArgs e)
        {

            try
            {
                int numEtudiant = Int32.Parse(txtNumEtudiant.Text);
                string strNom = txtNumEtudiant.Text;
                string strPrenom = txtPrenom.Text;
                string strAdresse = txtAdresse.Text;

                Etudiant objEtudiant = new Etudiant(numEtudiant, strNom, strPrenom, strAdresse);

                listEtudiant.Add(objEtudiant);

            }

            catch (InvalidCastException ex)
            {
                // recover from exception
                MessageBox.Show(ex.Message);

            }

        }

        private void cmdOKCours_Click(object sender, EventArgs e)
        {
            try
            {
                int numCours = Int32.Parse(txtNumCours.Text);
                string strCodeCours = txtCodeCours.Text;
                string strTitre = txtTitreCours.Text;
                int coefficient = Int32.Parse(txtCoefficient.Text) ;
                                
                Cours objCours = new Cours(numCours, strCodeCours, strTitre, coefficient);

                listCours.Add(objCours);


            }

            catch (InvalidCastException ex)
            {
                // recover from exception
                MessageBox.Show(ex.Message);

            }
        }

        private void cmdOKNote_Click(object sender, EventArgs e)
        {

            try
            {
                int numEtudiant = Int32.Parse(txtNumEtudiantLienCours.Text);
                int numCours = Int32.Parse(txtNumCoursLienEtudiant.Text);
                int note = Int32.Parse(txtNote.Text);

                // Note(int numEtudiant, int numCours, int note)

                Note objNote = new Note(numEtudiant, numCours, note);

                listNote.Add(objNote);


            }

            catch (InvalidCastException ex)
            {
                // recover from exception
                MessageBox.Show(ex.Message);

            }

        }

        private void cmdAnnulerNote_Click(object sender, EventArgs e)
        {
            txtNumEtudiantLienCours.Text = "";
            txtNumCoursLienEtudiant.Text = "";
            txtNote.Text = "";
        }

        private void cmdAnnulerEtudiant_Click(object sender, EventArgs e)
        {

            txtNumEtudiant.Text = "";
            txtNumEtudiant.Text = "";
            txtPrenom.Text = "";
            txtAdresse.Text = "";

        }

        private void cmdAnnulerCours_Click(object sender, EventArgs e)
        {

            txtNumCours.Text = "";
            txtCodeCours.Text = "";
            txtTitreCours.Text = "";
            txtCoefficient.Text = "";

        }

        private void cmdCreerFichierEtudiant_Click(object sender, EventArgs e)
        {

            // StringBuilder strContenuFichier = new StringBuilder();
            
            Etudiant objEtudiant;
            Cours objCours;
            Note objNote;

            int numEtudiantCourant;
            int numEtudiantTmp;

            int numCours;

            int i;
            int j;
            int k;

            int moyenne;
            int coefficientTotal;

            string strContenuFichier;

            string strCheminFichier;

            for (i = 0; i < listEtudiant.Count; i++)
            {

                // On fait une boucle sur la liste des etudiants
                objEtudiant = listEtudiant[i];

                moyenne = 0;
                coefficientTotal = 0;

                // On inscrit les informations des etudiants dans une chaine de caractere
                numEtudiantCourant = objEtudiant.getNumEtudiant();

                strContenuFichier = "<Etudiant>\n" + "numEtudiant:" + numEtudiantCourant + "\n";
                strContenuFichier = strContenuFichier + "Nom:" + objEtudiant.getNom() + "\n";
                strContenuFichier = strContenuFichier + "Prénom:" + objEtudiant.getPrenom() + "\n";
                strContenuFichier = strContenuFichier + "Adresse:" + objEtudiant.getAdresse() + "\n";
                strContenuFichier = strContenuFichier + "</Etudiant>\n";


                // On recherche les cours de l'etudiant et on va mettre ces informations dans la chaine de caractere
                for (j = 0; j < listNote.Count; j++)
                {

                    objNote = listNote[j];

                    numEtudiantTmp = objNote.getNumEtudiant();

                    if (numEtudiantTmp == numEtudiantCourant)
                    {

                        numCours = objNote.getNumCours();

                        // On cherche le cours dont le numero est numCours
                        for (k = 0; k < listCours.Count; k++)
                        {

                            objCours = listCours[k];
                            if (objCours.getNumCours() == numCours)
                            {

                                // On a trouve le cours. On ajoute ses information dans la chaine de caractere
                                strContenuFichier = strContenuFichier + "<Cours>\n" + "numCours:" + numCours + "\n";
                                strContenuFichier = strContenuFichier + "CodeCours:" + objCours.getCodeDuCours() + "\n";
                                strContenuFichier = strContenuFichier + "Titre:" + objCours.getTitreDuCours() + "\n";
                                strContenuFichier = strContenuFichier + "Note:" + objNote.getNote() + "\n";
                                strContenuFichier = strContenuFichier + "</Cours>" + "\n";

                                // On calcule la moyenne au fur et a mesure
                                moyenne = moyenne + objCours.getCoefficient() * objNote.getNote();
                                coefficientTotal = coefficientTotal + objCours.getCoefficient();

                            }


                        } // Fin for listCours

                    }

                } // Fin for listNote


                // On met a jour la note de l'etudiant
                                if (coefficientTotal > 0)
                {
                    
                    moyenne = moyenne / coefficientTotal;
                    objEtudiant.setMoyenne(moyenne);

                }
                

                // On cree le fichier dans le dossier Etudiant. Le nom du fichier est numEtudiant.txt

                strCheminFichier = @"Etudiant\" + numEtudiantCourant + ".txt" ;
               
                File.WriteAllText(strCheminFichier, strContenuFichier); 

            } // Fin for etudiant



        }

        private void cmdFindEtudiant_Click(object sender, EventArgs e)
        {

            Etudiant objEtudiant;

            int numEtudiantCourant;
            int numEtudiantTmp;

            int i;

            string strInfoEtudiant;

            numEtudiantCourant = Int32.Parse(txtRechercheEtudiant.Text);

            strInfoEtudiant = "";

            for (i = 0; i < listEtudiant.Count; i++)
            {

                objEtudiant = listEtudiant[i];

                // On inscrit les informations des etudiants dans une chaine de caractere
                numEtudiantTmp = objEtudiant.getNumEtudiant();

                if(numEtudiantTmp== numEtudiantCourant)
                {

                    strInfoEtudiant = "<Etudiant>\n" + "numEtudiant: " + numEtudiantCourant + "\n";
                    strInfoEtudiant = strInfoEtudiant + "Nom: " + objEtudiant.getNom() + "\n";
                    strInfoEtudiant = strInfoEtudiant + "Prénom: " + objEtudiant.getPrenom() + "\n";
                    strInfoEtudiant = strInfoEtudiant + "Adresse: " + objEtudiant.getAdresse() + "\n";
                    strInfoEtudiant = strInfoEtudiant + "</Etudiant>\n";

                }
   

            } // Fin For

            if (strInfoEtudiant == "")
            {

                strInfoEtudiant = "L'etudiant n'existe pas.";

            }

            MessageBox.Show(strInfoEtudiant);




        }

        private void cmdFiindCours_Click(object sender, EventArgs e)
        {

            Cours objCours;

            int numCoursCourant;
            int numCoursTmp;

            int i;

            string strInfoCours;

            numCoursCourant = Int32.Parse(txtRechercheCours.Text);

            strInfoCours = "";

            for (i = 0; i < listCours.Count; i++)
            {

                objCours = listCours[i];

                // On inscrit les informations des etudiants dans une chaine de caractere
                numCoursTmp = objCours.getNumCours();

                if (numCoursTmp == numCoursCourant)
                {

                    strInfoCours = "<Cours>\n" + "numCours: " + numCoursCourant + "\n";
                    strInfoCours = strInfoCours + "Code du cours: " + objCours.getCodeDuCours() + "\n";
                    strInfoCours = strInfoCours + "Titre du cours: " + objCours.getTitreDuCours() + "\n";
                    strInfoCours = strInfoCours + "Coefficient du cours: " + objCours.getCoefficient() + "\n";
                    strInfoCours = strInfoCours + "</Cours>\n";

                }


            } // Fin For

            if (strInfoCours == "")
            {

                strInfoCours = "Le cours n'existe pas.";

            }
            MessageBox.Show(strInfoCours);




        }

        private void cmdReleveDeNote_Click(object sender, EventArgs e)
        {



            // StringBuilder strContenuFichier = new StringBuilder();

            Etudiant objEtudiant;
            Cours objCours;
            Note objNote;

            int numEtudiantCourant;
            int numEtudiantTmp;

            int numCours;

            int i;
            int j;
            int k;

            int moyenne;
            int coefficientTotal;

            string strContenuFichier;

            string strCheminFichier;



            strContenuFichier = "                             Relevé de Notes\n\n\n\n";



            for (i = 0; i < listEtudiant.Count; i++)
            {

                // On fait une boucle sur la liste des etudiants
                objEtudiant = listEtudiant[i];

                moyenne = 0;
                coefficientTotal = 0;

                // On inscrit les informations des etudiants dans une chaine de caractere
                numEtudiantCourant = objEtudiant.getNumEtudiant();

                strContenuFichier = strContenuFichier + "numEtudiant: " + numEtudiantCourant + "              Groupe:\n";
                strContenuFichier = strContenuFichier + "Nom: " + objEtudiant.getNom() + "              Niveau\n";
                strContenuFichier = strContenuFichier + "Prénom:" + objEtudiant.getPrenom() + "              Année scolaire:\n";
                strContenuFichier = strContenuFichier + "Adresse:" + objEtudiant.getAdresse() + "\n";
                strContenuFichier = strContenuFichier + "\n\n\n\n\n\n\n\n\n";


                // On recherche les cours de l'etudiant et on va mettre ces informations dans la chaine de caractere
                for (j = 0; j < listNote.Count; j++)
                {

                    objNote = listNote[j];

                    numEtudiantTmp = objNote.getNumEtudiant();

                    if (numEtudiantTmp == numEtudiantCourant)
                    {

                        numCours = objNote.getNumCours();

                        // On cherche le cours dont le numero est numCours
                        for (k = 0; k < listCours.Count; k++)
                        {

                            objCours = listCours[k];
                            if (objCours.getNumCours() == numCours)
                            {

                                // On a trouve le cours. On ajoute ses information dans la chaine de caractere
                                strContenuFichier = strContenuFichier + "Matière                      | Coefficient                 |  NotestrContenuFichier\n\n";
                                strContenuFichier = strContenuFichier + "______________________________________________________________";
                                strContenuFichier = strContenuFichier  + "Titre:" + objCours.getTitreDuCours() + "|                     ";
                                strContenuFichier = strContenuFichier + "______________________________________________________________";

                                strContenuFichier = strContenuFichier +  objCours.getCoefficient() + "|                     ";
                                strContenuFichier = strContenuFichier  + objNote.getNote() + "\n\n";
                                

                            }


                        } // Fin for listCours

                    }

                } // Fin for listNote


                

                // On cree le fichier dans le dossier Etudiant. Le nom du fichier est numEtudiant.txt

                strCheminFichier = @"Etudiant\ReleveDeNote." + numEtudiantCourant + ".txt";

                File.WriteAllText(strCheminFichier, strContenuFichier);

            } // Fin for etudiant

        }
    }
}
