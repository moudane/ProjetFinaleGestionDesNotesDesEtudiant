﻿
namespace ProjetFinalGestionDesNotes
{
    partial class frmGestionDesNoted
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.cmdAnnulerEtudiant = new System.Windows.Forms.Button();
            this.cmdOKEtudiant = new System.Windows.Forms.Button();
            this.txtNom = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.txtAdresse = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.txtPrenom = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txtNumEtudiant = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.cmdAnnulerCours = new System.Windows.Forms.Button();
            this.cmdOKCours = new System.Windows.Forms.Button();
            this.txtNumCours = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.txtCodeCours = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.txtCoefficient = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.txtTitreCours = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.cmdAnnulerNote = new System.Windows.Forms.Button();
            this.cmdOKNote = new System.Windows.Forms.Button();
            this.txtNumCoursLienEtudiant = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.txtNote = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.txtNumEtudiantLienCours = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.cmdReleveDeNote = new System.Windows.Forms.Button();
            this.cmdCreerFichierEtudiant = new System.Windows.Forms.Button();
            this.txtEtudiant = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.cmdFindEtudiant = new System.Windows.Forms.Button();
            this.txtRechercheEtudiant = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.cmdFiindCours = new System.Windows.Forms.Button();
            this.txtRechercheCours = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.groupBox6.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.cmdAnnulerEtudiant);
            this.groupBox1.Controls.Add(this.cmdOKEtudiant);
            this.groupBox1.Controls.Add(this.txtNom);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.txtAdresse);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.txtPrenom);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.txtNumEtudiant);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Location = new System.Drawing.Point(54, 32);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(568, 209);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Ajouter un étudiant";
            // 
            // cmdAnnulerEtudiant
            // 
            this.cmdAnnulerEtudiant.Location = new System.Drawing.Point(435, 133);
            this.cmdAnnulerEtudiant.Name = "cmdAnnulerEtudiant";
            this.cmdAnnulerEtudiant.Size = new System.Drawing.Size(75, 23);
            this.cmdAnnulerEtudiant.TabIndex = 2;
            this.cmdAnnulerEtudiant.Text = "Annuler";
            this.cmdAnnulerEtudiant.UseVisualStyleBackColor = true;
            this.cmdAnnulerEtudiant.Click += new System.EventHandler(this.cmdAnnulerEtudiant_Click);
            // 
            // cmdOKEtudiant
            // 
            this.cmdOKEtudiant.Location = new System.Drawing.Point(340, 133);
            this.cmdOKEtudiant.Name = "cmdOKEtudiant";
            this.cmdOKEtudiant.Size = new System.Drawing.Size(75, 23);
            this.cmdOKEtudiant.TabIndex = 2;
            this.cmdOKEtudiant.Text = "OK";
            this.cmdOKEtudiant.UseVisualStyleBackColor = true;
            this.cmdOKEtudiant.Click += new System.EventHandler(this.cmdOKEtudiant_Click);
            // 
            // txtNom
            // 
            this.txtNom.Location = new System.Drawing.Point(136, 73);
            this.txtNom.Name = "txtNom";
            this.txtNom.Size = new System.Drawing.Size(100, 23);
            this.txtNom.TabIndex = 1;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(77, 81);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(37, 15);
            this.label2.TabIndex = 0;
            this.label2.Text = "Nom:";
            // 
            // txtAdresse
            // 
            this.txtAdresse.Location = new System.Drawing.Point(136, 125);
            this.txtAdresse.Name = "txtAdresse";
            this.txtAdresse.Size = new System.Drawing.Size(100, 23);
            this.txtAdresse.TabIndex = 1;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(63, 133);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(51, 15);
            this.label4.TabIndex = 0;
            this.label4.Text = "Adresse:";
            // 
            // txtPrenom
            // 
            this.txtPrenom.Location = new System.Drawing.Point(340, 78);
            this.txtPrenom.Name = "txtPrenom";
            this.txtPrenom.Size = new System.Drawing.Size(100, 23);
            this.txtPrenom.TabIndex = 1;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(276, 81);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(49, 15);
            this.label3.TabIndex = 0;
            this.label3.Text = "Prénom";
            // 
            // txtNumEtudiant
            // 
            this.txtNumEtudiant.Location = new System.Drawing.Point(136, 35);
            this.txtNumEtudiant.Name = "txtNumEtudiant";
            this.txtNumEtudiant.Size = new System.Drawing.Size(100, 23);
            this.txtNumEtudiant.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(19, 38);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(111, 15);
            this.label1.TabIndex = 0;
            this.label1.Text = "Numero d\'etudiant:";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.cmdAnnulerCours);
            this.groupBox2.Controls.Add(this.cmdOKCours);
            this.groupBox2.Controls.Add(this.txtNumCours);
            this.groupBox2.Controls.Add(this.label14);
            this.groupBox2.Controls.Add(this.txtCodeCours);
            this.groupBox2.Controls.Add(this.label5);
            this.groupBox2.Controls.Add(this.txtCoefficient);
            this.groupBox2.Controls.Add(this.label6);
            this.groupBox2.Controls.Add(this.txtTitreCours);
            this.groupBox2.Controls.Add(this.label7);
            this.groupBox2.Location = new System.Drawing.Point(648, 32);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(568, 209);
            this.groupBox2.TabIndex = 0;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Ajouter un cours";
            // 
            // cmdAnnulerCours
            // 
            this.cmdAnnulerCours.Location = new System.Drawing.Point(428, 140);
            this.cmdAnnulerCours.Name = "cmdAnnulerCours";
            this.cmdAnnulerCours.Size = new System.Drawing.Size(75, 23);
            this.cmdAnnulerCours.TabIndex = 11;
            this.cmdAnnulerCours.Text = "Annuler";
            this.cmdAnnulerCours.UseVisualStyleBackColor = true;
            this.cmdAnnulerCours.Click += new System.EventHandler(this.cmdAnnulerCours_Click);
            // 
            // cmdOKCours
            // 
            this.cmdOKCours.Location = new System.Drawing.Point(333, 140);
            this.cmdOKCours.Name = "cmdOKCours";
            this.cmdOKCours.Size = new System.Drawing.Size(75, 23);
            this.cmdOKCours.TabIndex = 12;
            this.cmdOKCours.Text = "OK";
            this.cmdOKCours.UseVisualStyleBackColor = true;
            this.cmdOKCours.Click += new System.EventHandler(this.cmdOKCours_Click);
            // 
            // txtNumCours
            // 
            this.txtNumCours.Location = new System.Drawing.Point(150, 38);
            this.txtNumCours.Name = "txtNumCours";
            this.txtNumCours.Size = new System.Drawing.Size(100, 23);
            this.txtNumCours.TabIndex = 7;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(41, 41);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(103, 15);
            this.label14.TabIndex = 3;
            this.label14.Text = "Numéro du cours:";
            // 
            // txtCodeCours
            // 
            this.txtCodeCours.Location = new System.Drawing.Point(150, 78);
            this.txtCodeCours.Name = "txtCodeCours";
            this.txtCodeCours.Size = new System.Drawing.Size(100, 23);
            this.txtCodeCours.TabIndex = 7;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(57, 86);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(87, 15);
            this.label5.TabIndex = 3;
            this.label5.Text = "Code du cours:";
            // 
            // txtCoefficient
            // 
            this.txtCoefficient.Location = new System.Drawing.Point(403, 78);
            this.txtCoefficient.Name = "txtCoefficient";
            this.txtCoefficient.Size = new System.Drawing.Size(100, 23);
            this.txtCoefficient.TabIndex = 8;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(277, 86);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(120, 15);
            this.label6.TabIndex = 4;
            this.label6.Text = "Coefficient du cours: ";
            // 
            // txtTitreCours
            // 
            this.txtTitreCours.Location = new System.Drawing.Point(403, 43);
            this.txtTitreCours.Name = "txtTitreCours";
            this.txtTitreCours.Size = new System.Drawing.Size(100, 23);
            this.txtTitreCours.TabIndex = 9;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(315, 46);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(82, 15);
            this.label7.TabIndex = 5;
            this.label7.Text = "Titre du cours:";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(95, 46);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(208, 15);
            this.label8.TabIndex = 6;
            this.label8.Text = "Creer un fichier pour chaque étudiant:";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.cmdAnnulerNote);
            this.groupBox3.Controls.Add(this.cmdOKNote);
            this.groupBox3.Controls.Add(this.txtNumCoursLienEtudiant);
            this.groupBox3.Controls.Add(this.label9);
            this.groupBox3.Controls.Add(this.txtNote);
            this.groupBox3.Controls.Add(this.label11);
            this.groupBox3.Controls.Add(this.txtNumEtudiantLienCours);
            this.groupBox3.Controls.Add(this.label12);
            this.groupBox3.Location = new System.Drawing.Point(54, 269);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(568, 234);
            this.groupBox3.TabIndex = 0;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Lier un etudiant à un cours";
            // 
            // cmdAnnulerNote
            // 
            this.cmdAnnulerNote.Location = new System.Drawing.Point(267, 184);
            this.cmdAnnulerNote.Name = "cmdAnnulerNote";
            this.cmdAnnulerNote.Size = new System.Drawing.Size(75, 23);
            this.cmdAnnulerNote.TabIndex = 21;
            this.cmdAnnulerNote.Text = "Annuler";
            this.cmdAnnulerNote.UseVisualStyleBackColor = true;
            this.cmdAnnulerNote.Click += new System.EventHandler(this.cmdAnnulerNote_Click);
            // 
            // cmdOKNote
            // 
            this.cmdOKNote.Location = new System.Drawing.Point(172, 184);
            this.cmdOKNote.Name = "cmdOKNote";
            this.cmdOKNote.Size = new System.Drawing.Size(75, 23);
            this.cmdOKNote.TabIndex = 22;
            this.cmdOKNote.Text = "OK";
            this.cmdOKNote.UseVisualStyleBackColor = true;
            this.cmdOKNote.Click += new System.EventHandler(this.cmdOKNote_Click);
            // 
            // txtNumCoursLienEtudiant
            // 
            this.txtNumCoursLienEtudiant.Location = new System.Drawing.Point(136, 102);
            this.txtNumCoursLienEtudiant.Name = "txtNumCoursLienEtudiant";
            this.txtNumCoursLienEtudiant.Size = new System.Drawing.Size(100, 23);
            this.txtNumCoursLienEtudiant.TabIndex = 17;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(30, 110);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(103, 15);
            this.label9.TabIndex = 13;
            this.label9.Text = "Numéro du cours:";
            // 
            // txtNote
            // 
            this.txtNote.Location = new System.Drawing.Point(315, 102);
            this.txtNote.Name = "txtNote";
            this.txtNote.Size = new System.Drawing.Size(100, 23);
            this.txtNote.TabIndex = 19;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(267, 110);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(36, 15);
            this.label11.TabIndex = 15;
            this.label11.Text = "Note:";
            // 
            // txtNumEtudiantLienCours
            // 
            this.txtNumEtudiantLienCours.Location = new System.Drawing.Point(136, 62);
            this.txtNumEtudiantLienCours.Name = "txtNumEtudiantLienCours";
            this.txtNumEtudiantLienCours.Size = new System.Drawing.Size(100, 23);
            this.txtNumEtudiantLienCours.TabIndex = 20;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(7, 67);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(123, 15);
            this.label12.TabIndex = 16;
            this.label12.Text = " Numéro de l\'étudiant";
            this.label12.Click += new System.EventHandler(this.label12_Click);
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.cmdReleveDeNote);
            this.groupBox4.Controls.Add(this.cmdCreerFichierEtudiant);
            this.groupBox4.Controls.Add(this.txtEtudiant);
            this.groupBox4.Controls.Add(this.label15);
            this.groupBox4.Controls.Add(this.label8);
            this.groupBox4.Location = new System.Drawing.Point(648, 269);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(568, 125);
            this.groupBox4.TabIndex = 0;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Fichier et impression";
            // 
            // cmdReleveDeNote
            // 
            this.cmdReleveDeNote.Location = new System.Drawing.Point(354, 86);
            this.cmdReleveDeNote.Name = "cmdReleveDeNote";
            this.cmdReleveDeNote.Size = new System.Drawing.Size(167, 23);
            this.cmdReleveDeNote.TabIndex = 16;
            this.cmdReleveDeNote.Text = "Imprimer relevé de note";
            this.cmdReleveDeNote.UseVisualStyleBackColor = true;
            this.cmdReleveDeNote.Click += new System.EventHandler(this.cmdReleveDeNote_Click);
            // 
            // cmdCreerFichierEtudiant
            // 
            this.cmdCreerFichierEtudiant.Location = new System.Drawing.Point(354, 42);
            this.cmdCreerFichierEtudiant.Name = "cmdCreerFichierEtudiant";
            this.cmdCreerFichierEtudiant.Size = new System.Drawing.Size(75, 23);
            this.cmdCreerFichierEtudiant.TabIndex = 15;
            this.cmdCreerFichierEtudiant.Text = "Créer";
            this.cmdCreerFichierEtudiant.UseVisualStyleBackColor = true;
            this.cmdCreerFichierEtudiant.Click += new System.EventHandler(this.cmdCreerFichierEtudiant_Click);
            // 
            // txtEtudiant
            // 
            this.txtEtudiant.Location = new System.Drawing.Point(232, 83);
            this.txtEtudiant.Name = "txtEtudiant";
            this.txtEtudiant.Size = new System.Drawing.Size(100, 23);
            this.txtEtudiant.TabIndex = 14;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(95, 86);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(111, 15);
            this.label15.TabIndex = 13;
            this.label15.Text = "Numero d\'etudiant:";
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.cmdFindEtudiant);
            this.groupBox5.Controls.Add(this.txtRechercheEtudiant);
            this.groupBox5.Controls.Add(this.label10);
            this.groupBox5.Location = new System.Drawing.Point(648, 405);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(568, 110);
            this.groupBox5.TabIndex = 0;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "Rechercher un étudiant";
            // 
            // cmdFindEtudiant
            // 
            this.cmdFindEtudiant.Location = new System.Drawing.Point(354, 38);
            this.cmdFindEtudiant.Name = "cmdFindEtudiant";
            this.cmdFindEtudiant.Size = new System.Drawing.Size(75, 23);
            this.cmdFindEtudiant.TabIndex = 13;
            this.cmdFindEtudiant.Text = "OK";
            this.cmdFindEtudiant.UseVisualStyleBackColor = true;
            this.cmdFindEtudiant.Click += new System.EventHandler(this.cmdFindEtudiant_Click);
            // 
            // txtRechercheEtudiant
            // 
            this.txtRechercheEtudiant.Location = new System.Drawing.Point(192, 38);
            this.txtRechercheEtudiant.Name = "txtRechercheEtudiant";
            this.txtRechercheEtudiant.Size = new System.Drawing.Size(100, 23);
            this.txtRechercheEtudiant.TabIndex = 10;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(57, 46);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(111, 15);
            this.label10.TabIndex = 6;
            this.label10.Text = " Numéro d\'étudiant";
            // 
            // groupBox6
            // 
            this.groupBox6.Controls.Add(this.cmdFiindCours);
            this.groupBox6.Controls.Add(this.txtRechercheCours);
            this.groupBox6.Controls.Add(this.label13);
            this.groupBox6.Location = new System.Drawing.Point(638, 534);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(568, 110);
            this.groupBox6.TabIndex = 0;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "Rechercher un cours";
            // 
            // cmdFiindCours
            // 
            this.cmdFiindCours.Location = new System.Drawing.Point(364, 38);
            this.cmdFiindCours.Name = "cmdFiindCours";
            this.cmdFiindCours.Size = new System.Drawing.Size(75, 23);
            this.cmdFiindCours.TabIndex = 13;
            this.cmdFiindCours.Text = "OK";
            this.cmdFiindCours.UseVisualStyleBackColor = true;
            this.cmdFiindCours.Click += new System.EventHandler(this.cmdFiindCours_Click);
            // 
            // txtRechercheCours
            // 
            this.txtRechercheCours.Location = new System.Drawing.Point(192, 38);
            this.txtRechercheCours.Name = "txtRechercheCours";
            this.txtRechercheCours.Size = new System.Drawing.Size(100, 23);
            this.txtRechercheCours.TabIndex = 10;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(57, 46);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(103, 15);
            this.label13.TabIndex = 6;
            this.label13.Text = " Numéro du cours";
            // 
            // frmGestionDesNoted
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1299, 697);
            this.Controls.Add(this.groupBox6);
            this.Controls.Add(this.groupBox5);
            this.Controls.Add(this.groupBox4);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Name = "frmGestionDesNoted";
            this.Text = "Gestion des notes";
            this.Load += new System.EventHandler(this.frmGestionDesNoted_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            this.groupBox6.ResumeLayout(false);
            this.groupBox6.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button cmdAnnulerEtudiant;
        private System.Windows.Forms.Button cmdOKEtudiant;
        private System.Windows.Forms.TextBox txtNom;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtAdresse;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtPrenom;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtNumEtudiant;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Button cmdAnnulerCours;
        private System.Windows.Forms.Button cmdOKCours;
        private System.Windows.Forms.TextBox txtCodeCours;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtCoefficient;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txtTitreCours;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.Button cmdAnnulerNote;
        private System.Windows.Forms.Button cmdOKNote;
        private System.Windows.Forms.TextBox txtNumCoursLienEtudiant;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox txtNote;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox txtNumEtudiantLienCours;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.ListBox lstEtudiant;
        private System.Windows.Forms.ListBox lstCours;
        private System.Windows.Forms.ListBox lstNote;
        private System.Windows.Forms.TextBox txtEtudiant;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.TextBox txtRechercheEtudiant;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.TextBox txtRechercheCours;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox txtNumCours;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Button cmdCreerFichierEtudiant;
        private System.Windows.Forms.Button cmdReleveDeNote;
        private System.Windows.Forms.Button cmdFindEtudiant;
        private System.Windows.Forms.Button cmdFiindCours;
    }
}